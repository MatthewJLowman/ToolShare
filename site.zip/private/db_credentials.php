<?php

// Keep database credentials in a separate file
// 1. Easy to exclude this file from source code managers
// 2. Unique credentials on development and production servers
// 3. Unique credentials if working with multiple developers

// localhost
define("DB_SERVER", "localhost");
define("DB_USER", "ufcbrn2ioh9hv");
define("DB_PASS", "2*12+hr1%g)/");
define("DB_NAME", "dbgmgoblwbwygo");


// a2hosting
// define("DB_SERVER", "localhost");
// define("DB_USER", " charli12_chain_gang");
// define("DB_PASS", 'RF2"JfXC9^e5t.2');
// define("DB_NAME", "charli12_chain_gang");


?>
