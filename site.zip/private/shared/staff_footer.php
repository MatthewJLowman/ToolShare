<footer>
  &copy; <?php echo date('Y'); ?> Tool Share
</footer>

</body>
</html>

<?php
  db_disconnect($database);
?>
